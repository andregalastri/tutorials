#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

#
poweroffLabel="<span font_family=\"Font Awesome 6 Pro\" weight=\"bold\"></span> Desligar"
rebootLabel="<span font_family=\"Font Awesome 6 Pro\" weight=\"bold\"></span> Reiniciar"
logoffLabel="<span font_family=\"Font Awesome 6 Pro\" weight=\"bold\"></span> Encerrar sessão"

poweroff="$poweroffLabel\0icon\x1f$assetsDir/power-off-light.svg"
reboot="$rebootLabel\0icon\x1f$assetsDir/refresh-light.svg"
logoff="$logoffLabel\0icon\x1f$assetsDir/exit-light.svg"

menuOptions="$logoff\n$reboot\n$poweroff"

#
uptime=$(uptime -p | sed -e 's/up //g; s/hour/hora/g; s/minute/minuto/g; s/day/dia/g')

#
choice="$(echo -e "$menuOptions" | rofi -dmenu -markup-rows -p "Ativo há $uptime" -theme "$powerMenuDir/rasi/power-menu.rasi" )"

case $choice in
    $poweroffLabel)
        "$dialogDir/power-dialog.sh" "power-off"
        ;;
    $rebootLabel)
        "$dialogDir/power-dialog.sh" "reboot"
        ;;
    $logoffLabel)
        "$dialogDir/power-dialog.sh" "logoff"
        ;;
esac

