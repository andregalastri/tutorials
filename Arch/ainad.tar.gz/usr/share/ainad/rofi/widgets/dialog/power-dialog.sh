#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

yes="Sim";
no="Não";
dialogOptions="$yes\n$no";

echo "
window {
    width: 320px;
}" > "$dialogDir/rasi/window-size.rasi";

function ChangeIconTo() {
    \cp -r "$assetsDir/$1" "$dialogDir/icon.svg";
};

function PreAction() {
    "$ainadBaseDir/exitCommands";
};

function ApplyAction() {
    case $1 in
        "power-off")
            PreAction;
            systemctl poweroff;
            ;;
        "reboot")
            PreAction;
            systemctl reboot;
            ;;
        "logoff")
            PreAction;
            openbox --exit;
            ;;
    esac;
};

ChangeIconTo "$1.svg";

case $1 in
    "power-off")
        message="Deseja realmente desligar o computador?";
        ;;
    "reboot")
        message="Deseja realmente reiniciar o computador?";
        ;;
    "logoff")
        message="Deseja realmente encerrar esta sessão?";
        ;;
esac

choice=$(echo -e "$dialogOptions" | rofi -dmenu -mesg "$message" -theme "$dialogDir/rasi/dialog.rasi");

if [[ "$choice" = "$yes" ]]; then
    ApplyAction "$1";
fi;
