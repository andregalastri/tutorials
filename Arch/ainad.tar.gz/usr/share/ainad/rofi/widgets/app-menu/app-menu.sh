#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

rofi -show drun -modi drun -theme "$appMenuDir/rasi/app-menu.rasi";
