#!/bin/bash

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

# The script needs a date as argument 1. It is stored in
# this variable to make it ease to understand.
argDate=$1;

# Loop to get the weekday names and store into the string
# with the style definitions.
for (( i=1, cellCount=0; i<=7; i++, cellCount++)); do

    # Everything inside the $styleDefinitions variable will
    # be stored into the calendar-grid.rasi file. This is
    # the way I found to create a dynamic grid with Rofi.
    styleDefinitions+="
        textbox-cell-$cellCount {\n
            vertical-align: 0.5;\n
            horizontal-align: 0.5;\n
            font: \"RobotoCondensed Bold 10\";\n
            padding: 4px;\n
            text-color: #8A94B1;\n
            background-color: #2E323D;\n
            content: \"$(ToUpperCase $(date "+%a" -d "2022-05-$i"))\";\n
        }\n";
done;

# Defines the current day.
styleDefinitions+="
    textbox-today-day {\n
        expand: false;\n
        font: \"RobotoCondensed 25\";\n
        text-color: #8A94B1;\n
        content: \"$(date "+%d")\";\n
        margin: -7px 0 0 0;\n
    }\n";

# Defines the current weekday name, converting it to
# uppercase.
styleDefinitions+="
    textbox-today-weekday {\n
        font: \"RobotoCondensed 10\";\n
        text-color: #8A94B1;\n
        content: \"$(ToUpperCase $(date "+%A"))\";\n
    }\n";

# Function that return the piece of the style that is
# the same as all other cells.
BaseCellDayStyle() {
    echo "
        vertical-align: 0.5;\n
        horizontal-align: 0.5;\n
        border-radius: 3px;\n
        padding: 4px;\n
        content: \"$1\";\n
        font: \"RobotoCondensed Bold 11\";\n
    ";
};

# Function that prints the styles of the common day
# cells.
CommonDayStyle() {
    echo "
    textbox-cell-$1 {\n
        $(BaseCellDayStyle $2)\n
        font: \"RobotoCondensed 11\";\n
        text-color: #8A94B1;\n
        background-color: transparent;\n
        font: \"RobotoCondensed 11\";\n
    }\n";
};

# Function that prints the styles of today's cell.
TodayDayStyle() {
    echo "
    textbox-cell-$1 {\n
        $(BaseCellDayStyle $2)\n
        text-color: #FFFFFF;\n
        background-color: #CF4D80;\n
    }\n";
};

# Function that prints the styles of sunday cells.
SundayDayStyle() {
    echo "
    textbox-cell-$1 {\n
        $(BaseCellDayStyle $2)\n
        text-color: #CF4D80;\n
        background-color: #2E323D;\n
    }\n";
};

# Functon that prints the styles of saturday cells.
SaturdayDayStyle() {
    echo "
    textbox-cell-$1 {\n
        $(BaseCellDayStyle $2)\n
        text-color: #8A94B1;\n
        background-color: #2E323D;\n
    }\n";
};

# Defines the starting day of every month. It will be
# incremented after each cell defined that is a day of
# the given month.
dayNumber=1;

# Defines the starting weekday of week. It will be
# incremented after each week completed.
weekdayNumber=0;

# Stores the current date. The format is YYYY-MM-DD.
currentDate=$(date "+%Y-%m-%d");

# Stores the year and month from the argument. The format
# is YYYY-MM.
currentMonthAndYear=$(date "+%Y-%m" -d $argDate);

# Stores which weekday number the first day of the
# month starts, which 1 is Sunday and 7 is Saturday.
firstWeekdayOfCurrentMonth=$(( $(date "+%w" -d "$argDate")+1 ));

# Stores the last day of the current month.
lastDayOfCurentMonth=$(date "+%d" -d "$argDate + 1 month - 1 day");

# Loops to create the styles of the entire calendar. Each
# iteration is a cell of a 6x7 grid (that is why the $i
# counter goes until number 42.
#
# The cellCount variable starts at 7 because the first 6
# cells were used to fill the weekday names before, at the
# start of this script.
for (( i=1, cellCount=7; i<=42; i++, cellCount++)); do
    
    # If the current counter is less than the position of
    # the first weekday number of the current month, or
    # if the current day number is bigger than the last
    # day of the current month, then the cell needs to be
    # empty.
    if (( i < firstWeekdayOfCurrentMonth )) || (( dayNumber > lastDayOfCurentMonth )); then
        styleDefinitions+=$(CommonDayStyle $cellCount "");
    else
        # Else, then the cell needs to be styled accordingly.
        styleDefinitions+=$(
            # If the current day number, month and year matches
            # the today's day, then the style applied is the
            # TodayDayStyle.
            if [ "$currentMonthAndYear-$(printf "%02d" $dayNumber)" = "$currentDate" ]; then
                TodayDayStyle $cellCount $dayNumber;
            
            # Else, if the current weekday number is equal to 6
            # it means that the current cell need to be styled
            # as a SaturdayDayStyle.
            elif [ "$weekdayNumber" = "6" ]; then
                SaturdayDayStyle $cellCount $dayNumber;

            # Else, if the current weekday number is equal to 0
            # it means that the current cell need to be styled
            # as a SundayDayStyle.
            elif [ "$weekdayNumber" = "0" ]; then
                SundayDayStyle $cellCount $dayNumber;

            # For any other cell, it will be styled as a
            # CommonDayStyle.
            else
                CommonDayStyle $cellCount $dayNumber;
            fi;
        );

        # As the current cell is not empty, it means that the
        # dayNumber needs to be incremented.
        ((dayNumber++));
    fi;
    
    # This condition checks if the weekday number reached
    # the maximum (6). If yes, then it restarts from zero.
    # If not, it increments it.
    if (( weekdayNumber >= 6 )); then
        weekdayNumber=0;
    else
        ((weekdayNumber++));
    fi;
done;

# All styles of each cell is stored into the following file
# that will be used by Rofi.
echo -en $styleDefinitions > "$calendarDir/rasi/calendar-grid.rasi";
