#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

# Navigation option labels.
previousYear="";
previousMonth="";
nextMonth="";
nextYear="";
navigationOptions="$previousYear\n$previousMonth\n\n\n\n$nextMonth\n$nextYear";

# Start the variable that stores the name of the month and
# the year that is displayed at the top of the window.
# This variable changes its value when the user navigates
# between months and years.
currentMonthAndYear=$(ToPascalCase $(date "+%B/%Y"));

# Starts the variable that is used as the starting point to
# build the calendar grid. This variable changes its value
# when the user navigates between month and years.
firstDayOfCurrentMonth=$(date "+%Y-%m-01");

# Stores the navigation button the user choose.
choice="";

# The script keeps running into a infinite loop until the
# user click outside the window or choose a invalid option,
# which ends the script.
while true; do

    # Build the .rasi file that displays the calendar grid
    # with the days properly positioned.
    "$calendarDir/build-calendar-grid.sh" $firstDayOfCurrentMonth $choice;

    # Launch the calendar and waits the user to choose an
    # option.
    choice=$(
        echo -en "$navigationOptions" |
        rofi -dmenu -p "$currentMonthAndYear" -select "$choice" -theme "$calendarDir/rasi/calendar.rasi"
    );

    # Checks the choice of the user after he clicks on a
    # button or outside the window.
    #
    # The valid buttons are the arrows left and right. Each
    # of them modifies the current calendar date by
    # adding or removing month or years.
    #
    # Any invalid option (like clicking outside the window)
    # makes the window close and end the script.
    case $choice in
        "")
            modifier="+ 1 month";
            ;;
        "")
            modifier="+ 1 year";
            ;;
        "")
            modifier="- 1 month";
            ;;
        "")
            modifier="- 1 year";
            ;;
        *)
            exit 0;
            ;;
    esac;

    # Changes the variables that store the current month and
    # year and the first day of the current date based on the
    # modifier.
    currentMonthAndYear=$(ToPascalCase $(date "+%B/%Y" -d "$firstDayOfCurrentMonth $modifier"));
    firstDayOfCurrentMonth=$(date "+%Y-%m-01" -d "$firstDayOfCurrentMonth $modifier");

    # A interval between the windows. Helps the script to not
    # misunderstand the click on the button as an outside
    # click.
    sleep 0.1;
done;
