#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

rofi -no-config -show app-manager -modi "app-manager:$appManagerDir/app-manager.sh" -theme "$appManagerDir/rasi/app-manager.rasi";
