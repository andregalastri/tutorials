#!/bin/bash
echo -en "asdasd\0info\x1fasdasd\n"
echo -en "123\0info\x1f123\n"

if [[ "$ROFI_INFO" != "" ]]; then
    notify-send "my info: ${ROFI_INFO} "
fi