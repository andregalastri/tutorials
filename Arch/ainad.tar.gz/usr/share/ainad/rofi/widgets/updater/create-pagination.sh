#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

# Importing package list
source "$updaterDir/variables.sh";

totalPages=$(( (numberOfPackages+packagesPerPage-1)/packagesPerPage ));
endAt=$(( currentPage*packagesPerPage ));
startsFrom=$(( endAt-packagesPerPage ));

linesToShow="line-label";

for (( i=$startsFrom; i<$endAt; i++)); do
    if (( i >= numberOfPackages )); then
        break;
    fi
    linesToShow+=", line-$i";
done;

styleDefinitions+="
    update-list {
        children: [$linesToShow];
    }
";

selectedPackages=0;

for status in ${updateStatus[@]}; do
    if (( status == 1 )); then
        (( selectedPackages++ ));
    fi;
done;

if (( numberOfPackages > 1 )); then
    styleDefinitions+="
        textbox-number-of-packages {
            vertical-align: 0.5;
            content: \"$numberOfPackages novas atualizações | $selectedPackages selecionados \";
        }
    ";
else
    styleDefinitions+="
        textbox-number-of-packages {
            vertical-align: 0.5;
            content: \"$numberOfPackages nova atualização |  $selectedPackages selecionado\";
        }
    ";
fi;

styleDefinitions+="
    textbox-pagination {
        vertical-align: 0.5;
        expand: false;
        content: \"$currentPage de $totalPages\";
    }
";

if (( totalPages > 1 )); then
    if (( currentPage == 1 )); then
        navigationDefinitions+="children: [textbox-number-of-packages, button-tools-next, textbox-pagination];\n";
    elif (( currentPage > 1 && currentPage < totalPages )); then
        navigationDefinitions+="children: [textbox-number-of-packages, button-tools-previous, button-tools-next, textbox-pagination];\n";
    else
        navigationDefinitions+="children: [textbox-number-of-packages, button-tools-previous, textbox-pagination];\n";
    fi;

    styleDefinitions+="
        navigation {
            $navigationDefinitions
        }
    ";
fi;

echo -e "$styleDefinitions" > "$updaterDir/rasi/pagination.rasi";
