#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

rofi -no-config -show updater -modi "updater:$updaterDir/updater.sh" -theme "$updaterDir/rasi/updater.rasi";
