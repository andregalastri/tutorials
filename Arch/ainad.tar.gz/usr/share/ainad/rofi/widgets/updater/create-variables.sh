#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

# Gets the list of updates that comes as an argument array.
updateList=("$@");

# Each update in the $updateList array is stored as a string.
# The string comes in a format, as follows:
#
#   package-name old-version -> new-version
#
#   Example:
#   "firefox 104.0.0 -> 105.0.1" "xfce4-terminal 1.0.3 -> 1.0.4"
#
# The information we need are the package name, the old version
# and the new version, so, we need to break each of these strings
# using the space as the delimiter.
for packageString in "${updateList[@]}"
do
    # That is what this readarray do. It splits the string based
    # on the spaces and store the pieces into an array.
    #
    #   This means that the string
    #   "firefox 104.0.0 -> 105.0.1"
    #
    #   Will be stored as:
    #   [0]="firefox" [1]="104.0.0" [2]="->" [3]="105.0.1"
    readarray -d " " -t packageArray <<<"$packageString";

    # Now we can store the pieces we need into their proper
    # arrays.

    # This array will store only the package names.
    packageNameArray+=(${packageArray[0]});

    # This array will store only the old versions.
    packageCurrentVersionArray+=(${packageArray[1]});

    # This array will store only the new versions.
    packageNewVersionArray+=($(echo ${packageArray[3]} | sed "s/\n//"));

    # And it is easy to get the data from these arrays
    # because each update is stored in the same index.
    #
    # Example, if the index 0 of the $packageNameArray
    # stores the package name "firefox", then we know that
    # the index 0 of the $packageCurrentVersionArray will
    # return to us the current version of the "firefox",
    # because everything array here has the same numbers
    # of indexes and each index is owned by a update.
    
    # In the popup screen, the user can choose which
    # package will be installed. If its status is zero (0),
    # then the package won't be installed. If it is one (1),
    # it will be.
    #
    # By default, every package are marked, so their status
    # needs to be one (1). The user can change this later.
    updateStatusArray+=(1);
done;

# All updates will be stored in this file to be used by the
# updater.sh script.
variablesFile="$updaterDir/variables.sh";

echo "#!/bin/sh" > "$variablesFile";
echo $(ExportArray 'packageName' "${packageNameArray[@]}") >> "$variablesFile";
echo $(ExportArray 'packageCurrentVersion' "${packageCurrentVersionArray[@]}") >> "$variablesFile";
echo $(ExportArray 'packageNewVersion' ${packageNewVersionArray[@]}) >> "$variablesFile";
echo $(ExportArray 'updateStatus' ${updateStatusArray[@]}) >> "$variablesFile";

# The packagesPerPage variable defines how many updates
# will be show per page in the popup screen.
echo "packagesPerPage=10;" >> "$variablesFile";

# The currentPage variable defines where the user is at
# the popup screen. By default it always starts in the
# page 1.
echo "currentPage=1;" >> "$variablesFile";

# The numberOfPackages variable defines how many packages
# are available to update.
echo "numberOfPackages=${#updateList[@]};" >> "$variablesFile";
