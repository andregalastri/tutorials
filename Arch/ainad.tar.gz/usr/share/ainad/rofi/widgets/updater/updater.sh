#!/usr/bin/env bash

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

# Importing package list
source "$updaterDir/variables.sh";

function UpdateVariables() {
    packageNameArray=(${packageName[*]});
    packageCurrentVersionArray=(${packageCurrentVersion[*]});
    packageNewVersionArray=(${packageNewVersion[*]});
    updateStatusArray=(${updateStatus[*]});

    variablesFile="$updaterDir/variables.sh";

    echo "#!/bin/sh" > "$variablesFile";
    echo $(ExportArray 'packageName' "${packageNameArray[*]}") >> "$variablesFile";
    echo $(ExportArray 'packageCurrentVersion' "${packageCurrentVersionArray[*]}") >> "$variablesFile";
    echo $(ExportArray 'packageNewVersion' ${packageNewVersionArray[*]}) >> "$variablesFile";
    echo $(ExportArray 'updateStatus' ${updateStatusArray[*]}) >> "$variablesFile";
    echo "packagesPerPage=$packagesPerPage;" >> "$variablesFile";
    echo "currentPage=$currentPage;" >> "$variablesFile";
    echo "numberOfPackages=$numberOfPackages;" >> "$variablesFile";

    "$updaterDir/create-package-list.sh";
};

function ChangeUpdateStatus() {
    sleep 0.07;
    index=$(( (currentPage*packagesPerPage)-packagesPerPage+$1 ));
    updateStatus[$index]=$(
        if [[ "${updateStatus[$index]}" = "0" ]]; then
            echo "1";
        else
            echo "0";
        fi;
    );

    UpdateVariables;

    killall -9 rofi;
    "$updaterDir/create-pagination.sh";
    "$updaterDir/launch-updater.sh";
};

function ChangePage() {
    sleep 0.07;
    if [[ "$1" = "next" ]]; then
        (( currentPage++ ));
    else
        (( currentPage-- ));
    fi;

    UpdateVariables;

    killall -9 rofi;
    "$updaterDir/create-pagination.sh";
    "$updaterDir/launch-updater.sh";
};

function ApplyUpdate() {
    sleep 0.07;
    
    i=0;
    selectedPackages=();

    for status in ${updateStatus[*]}; do
        if (( status == 1 )); then
            selectedPackages+=("${packageName[$i]}");
        fi;

        (( i++ ));
    done;

    if (( ${#selectedPackages[*]} <= 0 )); then
        dunstify -i "dialog-warning" -t 10000 "Atenção!" "É necessário selecionar ao menos um pacote de atualização.";
    else
        killall -9 rofi;

        xfce4-terminal -e "$updaterDir/apply-updates.sh \"${selectedPackages[*]}\"";

        sleep 1;
        local pid="$(pgrep -f -n "$updaterDir/apply-updates.sh")";

        while kill -0 "$pid"; do
            sleep 1;
        done;

        if [[ "$?" = "0" ]]; then
            dunstify -i "package-installed-updated" -t 10000 "Concluído!" "Os pacotes foram atualizados com sucesso!";
        else
            dunstify -i "dialog-error" -t 10000 "Atenção!" "Houve uma falha durante a atualização. Os pacotes podem não ter sido atualizados.";
        fi;

        PolybarCheckUpdates;
    fi;
};

echo -e "\0use-hot-keys\x1ftrue";

case $ROFI_RETV in
    10) ChangeUpdateStatus 0;;
    11) ChangeUpdateStatus 1;;
    12) ChangeUpdateStatus 2;;
    13) ChangeUpdateStatus 3;;
    14) ChangeUpdateStatus 4;;
    15) ChangeUpdateStatus 5;;
    16) ChangeUpdateStatus 6;;
    17) ChangeUpdateStatus 7;;
    18) ChangeUpdateStatus 8;;
    19) ChangeUpdateStatus 9;;
    20) ChangeUpdateStatus 10;;
    21) ChangeUpdateStatus 11;;
    22) ChangeUpdateStatus 12;;
    23) ChangeUpdateStatus 13;;
    24) ChangeUpdateStatus 14;;
    25) ChangePage "next";;
    26) ChangePage "previous";;
    27) ApplyUpdate;;
esac

echo -e "-";
