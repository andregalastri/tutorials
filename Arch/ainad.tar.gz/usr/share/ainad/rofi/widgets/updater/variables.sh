#!/bin/sh
packageName=(firefox git hwdata iproute2 libbpf linux-headers);
packageCurrentVersion=(105.0.1-1 2.37.3-1 0.362-2 5.19.0-1 0.8.1-1 5.19.12.arch1-1);
packageNewVersion=(105.0.2-1 2.38.0-1 0.363-1 5.19.0-2 1.0.1-1 5.19.13.arch1-1);
updateStatus=(1 1 1 1 1 1);
packagesPerPage=10;
currentPage=1;
numberOfPackages=6;
