#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

# Importing package list
source "$updaterDir/variables.sh";

styleDefinitions='
icon-up-to-date {
    expand: false;
    filename: @varIconCheck;
    size: 90px;
}

textbox-up-to-date {
    font: "RobotoCondensed 18px";
    content: "Seu sistema está atualizado!";
    horizontal-align: 0.5;
}

up-to-date-container {
    children: [icon-up-to-date, textbox-up-to-date];
    background-color: transparent;
    padding: 70px 5px;
}

mainbox {
    children: [textbox-header-text, textbox-content-text, content-information, up-to-date-container, tools-bottom];
}

tools-bottom {
    children: [button-tools-close];
}';

echo -e "$styleDefinitions" > "$updaterDir/rasi/package-list.rasi";
