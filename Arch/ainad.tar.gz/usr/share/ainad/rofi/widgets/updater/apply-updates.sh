#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

selectedPackages=($@);
logFile="$updaterDir/logs/$(date "+%Y-%m-%d %H:%M:%S").txt";

touch "$logFile";

echo -e 'Executando comando:\n   yay -Syy\n\n' > "$logFile";
echo -e "Para prosseguir na atualização, por favor, informe sua senha";
yay -Syy | tee -a "$logFile";

echo -e '\n\n=====================================================' >> "$logFile"
echo -e "Executando comando:\n   yay --noprovides --answerdiff None --answerclean All --mflags --noconfirm -S ${selectedPackages[*]}\n\n" >> "$logFile";
echo "y" | LANG=C yay --noprovides --answerdiff None --answerclean All --mflags --noconfirm -S ${selectedPackages[*]} | tee -a "$logFile";

echo -e '\n==================================================' | tee -a "$logFile"
echo -e '- Fim do log de atualização.' | tee -a "$logFile"
#notify-send -h int:value:1.2 -h string:synchronous:my-progress "Progress"