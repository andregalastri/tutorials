#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

# Importing package list
source "$updaterDir/variables.sh";

actionNumber=1;

for (( i=0; i<$numberOfPackages; i++)); do

    checkboxPath="$assetsDir/square-check-solid.svg";

    if [[ "${updateStatus[$i]}" = "0" ]]; then
        checkboxPath="$assetsDir/square.svg";
    fi;

    styleDefinitions+=$(echo "
    icon-status-$i {
        expand: false;
        filename: \"$checkboxPath\";
        size: 20px;
        cursor: pointer;
        action: \"kb-custom-$actionNumber\";
    }

    textbox-package-name-$i {
        content: \"${packageName[$i]}\";
    }

    textbox-package-old-version-$i {
        content: \"${packageCurrentVersion[$i]}\";
    }

    textbox-package-new-version-$i {
        text-color: #0b985d;
        content: \"${packageNewVersion[$i]}\";
    }

    line-$i {
        orientation: horizontal;
        children: [icon-status-$i, textbox-package-name-$i, textbox-package-old-version-$i, textbox-package-new-version-$i];
        spacing: 5px;
    }");

    if (( actionNumber >= packagesPerPage )); then
        actionNumber=1;
    else
        (( actionNumber++ ));
    fi;
done;

echo -e "$styleDefinitions" > "$updaterDir/rasi/package-list.rasi";
