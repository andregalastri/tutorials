#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

# Dialog option labels.
desktop="Na área de trabalho";
login="Na tela de login";
both="Em ambas telas";
cancel="Cancelar";
dialogOptions="$desktop\n$login\n$both\n$cancel";

# Base theme file location.
themeFile="$backgroundDir/rasi/set-as-background.rasi";

# Everytime this script is called, it writes the base theme file
# from scretch. This is the way I found to make it always show the
# selected image right in the popup.
echo "@import \"../../base-definitions.rasi\"

window {
    width: 800px;
}

mainbox {
    children: [textbox-header-text, textbox-content-text, icon-background-image, tools-bottom];
}

listview {
    expand: true;
    columns: 4;
    lines: 1;
    fixed-columns: true;
    scrollbar: false;
}

element {
    background-color: #2e323d;
}

element-text {
    format: bold;
    horizontal-align: 0.5;
}

textbox-header-text {
    content: \"Definir como plano de fundo\";
}

textbox-content-text {
    content: \"Onde você gostaria de aplicar este plano de fundo?\";
}

tools-bottom {
    children: [listview];
    margin: 20px 0 0 0;
}

icon-background-image {
    filename: \"$1\";
    size: 800px;
    padding: -250px;
    border-radius: 3px;
}
" > "$themeFile";

# Launch Rofi pointing the theme file that was written above
# and waits for the choice.
choice=$(
    echo -e "$dialogOptions" |
    rofi -dmenu -theme "$themeFile"
);


# This function runs Nitrogen to set up the wallpaper at the
# desktop.
SetAtDesktop() {
    nitrogen --save --set-zoom-fill "$1";
}

# This function copies the selected file to the location
# of the SDDM theme with the name "background.jpg" to show
# the image as a background image of the login screen.
SetAtLoginScreen() {
    \cp -r "$1" "/usr/share/sddm/themes/sugar-candy/background.jpg";
}

# Checks which choice the user made and run the proper
# function.
case $choice in
    "$desktop")
        SetAtDesktop "$1";
        ;;
    "$login")
        SetAtLoginScreen "$1";
        ;;
    "$both")
        SetAtDesktop "$1";
        SetAtLoginScreen "$1";
        ;;
    *)
        # If the user choose any other option, it will check
        # if the "keep-open" argument was set. If true, it
        # rerun the background browser.
        if [[ "$2" = "keep-open" ]]; then
            "$backgroundDir/browse-backgrounds.sh";
        else
            exit 0;
        fi;
        ;;
esac;
