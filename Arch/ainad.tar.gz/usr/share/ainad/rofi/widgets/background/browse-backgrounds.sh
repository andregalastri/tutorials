#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

# The base folder where the backgrounds are.
bgDir="/usr/share/backgrounds";

# Gets the list of files inside the base folder and stores in an array.
readarray -t fileList < <(ls "$bgDir");

# This variable will be incremented to help find what is the last file of the list.
i=1;

# For each file in the list, the following commands will be done.
for fileName in "${fileList[@]}"; do
    # Checks if the current i value is equal as the number of files in the base
    # folder. If it isn't, then a linebreak will be placed at the end of the
    # current item. If it isn't, them it will be empty.
    if (( $i < ${#fileList[@]} )); then
        linebreak="\n";
    else
        linebreak="";
    fi;

    # Checks if the file is a valid image. If its MIME type starts with "image/"
    # then it is stored as an available image. The file name is stored and its
    # icon is the image itself.
    if [[ "$(xdg-mime query filetype "$bgDir/$fileName")" == "image/"* ]]; then
        availableImages+=("$fileName\0icon\x1f$bgDir/$fileName$linebreak");
    fi;

    (( i++ ));
done;

# Launches Rofi listing the available images and waits the user to choose.
choice=$(
    echo -e "${availableImages[@]}" |
    rofi -dmenu -theme "$backgroundDir/rasi/browse-backgrounds.rasi"
);

# Trims the possible empty space infront of the choice, to prevent the file
# not be found.
choice=$(echo "$choice" | sed "s/^ //");

# If the choice is not empty, another script is called to ask how the image
# will be applied.
if [[ "$choice" != "" ]]; then
    "$backgroundDir/set-as-background.sh" "$bgDir/$choice" "keep-open";
fi;
