#!/bin/sh

# Directories
assetsDir="$ainadBaseDir/rofi/assets";
backgroundDir="$ainadBaseDir/rofi/widgets/background";
calendarDir="$ainadBaseDir/rofi/widgets/calendar";
updaterDir="$ainadBaseDir/rofi/widgets/updater";
dialogDir="$ainadBaseDir/rofi/widgets/dialog";
powerMenuDir="$ainadBaseDir/rofi/widgets/power-menu";
appMenuDir="$ainadBaseDir/rofi/widgets/app-menu";
appManagerDir="$ainadBaseDir/rofi/widgets/app-manager";

# Polybar
polybarBg=$(pgrep polybar | sed -n '1p');
polybarMain=$(pgrep polybar | sed -n '2p');
