#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

while true; do
    HideBarOnFullscreen;
    PolybarRefreshTaskBar;
    sleep 2;
done;
