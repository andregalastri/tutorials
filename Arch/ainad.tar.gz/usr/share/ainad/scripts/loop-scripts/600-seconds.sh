#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

while true; do
    PolybarCheckUpdates;
    sleep 600;
done;
