#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/globals.sh";

# Convert strings to UPPER case.
function ToUpperCase() {
    echo ${1^^};
};

# Convert strings to Capital case.
function ToPascalCase() {
    echo ${1^};
};

# Creates an string with a name and its values
# to be exported to a file.
function ExportArray() {
    local name=$1;
    shift;
    local values=$@;
    echo "$name=(${values[@]});";
};

function CurrentDir() {
    echo "${$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd)//$'\n'/}";
};

function PolybarCheckUpdates() {
    polybar-msg -p $polybarMain action "#check-updates.hook.0";
};

function PolybarRefreshTaskBar() {
    polybar-msg -p $polybarMain action "#task-bar.hook.0";
};

function PermanentlyDelete() {
    gsettings set org.nemo.preferences enable-delete true;

    sleep 0.2;

    xdotool keyup Control;
    xdotool keyup Delete;
    xdotool keydown Shift+Delete;

    sleep 0.2;

    gsettings set org.nemo.preferences enable-delete false;
    xdotool keyup Delete;
    xdotool keyup Shift;
};

status=0;

function HideBarOnFullscreen() {
    windowState=$(xprop -id $(xprop -root 32x '\t$0' _NET_ACTIVE_WINDOW | cut -f 2) _NET_WM_STATE | sed "s/_NET_WM_STATE(ATOM) = //")

    if [[ "$windowState" = "_NET_WM_STATE_FULLSCREEN" ]]; then
        if (( status == 1 )); then
            polybar-msg cmd hide;
            status=0;
        fi;
    else
        if (( status == 0 )); then
            # Polybar Bg
            polybar-msg -p $polybarBg cmd show;
            # Polybar Main
            polybar-msg -p $polybarMain cmd show;
            status=1;
        fi;
    fi;
};

function KillScript() {
    pkill -f "/bin/sh $1";
};

function GetScriptPid() {
    echo "$(pgrep -f -n "$1")";
};
