#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

PermanentlyDelete;
