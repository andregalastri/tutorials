#!/bin/sh
active_window=$(xprop -root _NET_ACTIVE_WINDOW|cut -d ' ' -f 5|sed -e 's/../0&/2');

current_display=$(wmctrl -d|grep "*"|awk '{print $1}');

color1="FFFFFF";

active_window_decoration_style_left_side="%{F#$color1}%{+u}%{u#$color1}";
active_window_decoration_style_right_side="%{-u}%{F-}";

current_windows=$(wmctrl -lx|awk -v current_display="$current_display" -v active_window="$active_window" -v active_window_decoration_style_left_side="$active_window_decoration_style_left_side" -v active_window_decoration_style_right_side="$active_window_decoration_style_right_side" '
{
    if ($2==current_display) {
		window_title=$3

        icon["gimp"]="%{T10}"
        icon["mousepad"]="%{T8}"
        icon["nemo.nemo"]="%{T8}"
        icon["properties"]="%{T8}"
        icon["terminal"]="%{T8}"
        icon["xterm"]="%{T8}"
        icon["google-chrome"]="%{T9}"
        icon["firefox"]="%{T9}"
        icon["gnome-font-viewer"]="%{T8}"
        icon["gnome-disks"]="%{T8}"
        icon["gpick"]="%{T8}"
        icon["n/a"]="%{T7}"
        icon["nm-connection-editor"]="%{T8}"
        icon["engrampa"]="%{T8}"
        icon["vlc"]="%{T10}"
        icon["inkscape"]="%{T10}"
        icon["fontforge"]="%{T10}"
        icon["pavucontrol"]="%{T8}"
        icon["arandr"]="%{T8}"
        icon["viewnior"]="%{T8}"
        icon["nitrogen"]="%{T8}"
        icon["lxinput"]="%{T8}"
        icon["lxappearance"]="%{T8}"
        icon["telegram"]="%{T9}"
        icon["kvantum"]="%{T10}"
        icon["dconf-editor"]="%{T8}"
        icon["xreader.Xreader"]="%{T8}"
        icon["gnome-system-monitor"]="%{T8}"
        icon["lxtask"]="%{T8}"
        icon["galculator"]="%{T8}"
        icon["rhythmbox"]="%{T8}"
        icon["polkit"]="%{T8}"
        icon["authentication"]="%{T8}"
        icon["file_progress.nemo"]="%{T8}"

        for (i in icon) {
            appName=i
            appIcon=icon[i]

            if (match(tolower(window_title), appName) > 0) {
                window_title=appIcon
                break
            }
        }

#        window_title=""
        
		if ($1==active_window) {
			window_title=active_window_decoration_style_left_side window_title active_window_decoration_style_right_side
			window_title=active_window_decoration_style_left_side window_title active_window_decoration_style_right_side
		}
		print "%{A1: wmctrl -ia "$1" & disown:} "window_title"%{T-} %{A}"
	}
}');
#
# Decorated version END
#######################

echo $current_windows;
