#!/bin/sh

# Importing common stuff
source "$ainadBaseDir/scripts/functions.sh";

# Gets the list of updates and stores in an array.
#
# IMPORTANT: The "checkupdates" command NEEDS to run last
# because it cancels any following commands if there is no
# update available.
readarray -t updateList < <(yay -Qua && checkupdates);

# If the number of available updates are bigger than zero
# then it runs scripts to create all that is needed to show
# the popup screen.
#
# It also prints the icon that is shown in the bar.
if (( ${#updateList[@]} > 0 )); then
    "$updaterDir/create-variables.sh" "${updateList[@]}";
    "$updaterDir/create-package-list.sh";
    "$updaterDir/create-pagination.sh";

    echo "%{T5}%{T-}";
else
    "$updaterDir/create-up-to-date-information.sh";
    echo "";
fi;
