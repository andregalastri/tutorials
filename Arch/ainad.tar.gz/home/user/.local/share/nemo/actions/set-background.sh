#!/bin/sh

"$ainadBaseDir/rofi/widgets/background/set-as-background.sh" "$1";
